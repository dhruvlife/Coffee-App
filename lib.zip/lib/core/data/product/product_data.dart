import 'package:figmawc/utils/constants/app_image_strings.dart';

class ProductData {
  final String image;
  final String name;
  final String category;
  final String description;
  final double rating;
  final double price;
  final String size;
  final int byRate;

  ProductData({
    required this.image,
    required this.name,
    required this.category,
    required this.description,
    required this.rating,
    required this.price,
    required this.size,
    required this.byRate,
  });
 static List<ProductData> products = [    
  ProductData(
    image: AppImageStrings.product1,
    size: "",
    name: 'Classic Latte',
    category: 'Hot Coffee',
    description: 'A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.',
    rating: 4.2,
    price: 3.0,
    byRate: 25,
  ),
  
  ProductData(
    image: AppImageStrings.product2,
    size: "",
    name: 'Espresso Shot',
    category: 'Hot Coffee',
    description: 'A strong espresso shot for a perfect start.',
    rating: 4.5,
    price: 2.5,
    byRate: 30,
  ),
  ProductData(
    image: AppImageStrings.product3,
    size: "",
    name: 'Cappuccino Delight',
    category: 'Hot Coffee',
    description: 'A delightful cappuccino with frothy milk.',
    rating: 4.3,
    price: 3.5,
    byRate: 22,
  ),
  ProductData(
    image: AppImageStrings.product4,
    size: "",
    name: 'Mocha Bliss',
    category: 'Hot Coffee',
    description: 'A rich mocha blend of coffee and chocolate.',
    rating: 4.6,
    price: 4.0,
    byRate: 35,
  ),
  ProductData(
    image: AppImageStrings.product5,
    size: "",
    name: 'Caramel Macchiato',
    category: 'Hot Coffee',
    description: 'A sweet caramel macchiato with espresso.',
    rating: 4.4,
    price: 4.2,
    byRate: 28,
  ),
  ProductData(
    image: AppImageStrings.product1,
    size: "",
    name: 'Iced Americano',
    category: 'Cold Coffee',
    description: 'A refreshing iced Americano with bold flavor.',
    rating: 4.1,
    price: 3.8,
    byRate: 20,
  ),
  ProductData(
    image: AppImageStrings.product2,
    size: "",
    name: 'Vanilla Cold Brew',
    category: 'Cold Coffee',
    description: 'Smooth cold brew infused with vanilla flavor.',
    rating: 4.3,
    price: 4.5,
    byRate: 26,
  ),
  ProductData(
    image: AppImageStrings.product3,
    size: "",
    name: 'Hazelnut Frappe',
    category: 'Cold Coffee',
    description: 'A creamy hazelnut frappe with whipped cream.',
    rating: 4.5,
    price: 4.7,
    byRate: 32,
  ),
  ProductData(
    image: AppImageStrings.product4,
    size: "",
    name: 'Iced Mocha',
    category: 'Cold Coffee',
    description: 'A delicious iced mocha with a chocolate twist.',
    rating: 4.2,
    price: 4.0,
    byRate: 29,
  ),
  ProductData(
    image: AppImageStrings.product5,
    size: "",
    name: 'Caramel Iced Latte',
    category: 'Cold Coffee',
    description: 'A caramel-infused iced latte with espresso.',
    rating: 4.4,
    price: 4.3,
    byRate: 31,
  ),
  ProductData(
    image: AppImageStrings.product1,
    size: "",
    name: 'Chai Latte',
    category: 'Tea',
    description: 'A spiced chai latte with a creamy texture.',
    rating: 4.3,
    price: 3.2,
    byRate: 22,
  ),
  ProductData(
    image: AppImageStrings.product2,
    size: "",
    name: 'Matcha Green Tea',
    category: 'Tea',
    description: 'A refreshing matcha green tea with antioxidants.',
    rating: 4.6,
    price: 4.8,
    byRate: 27,
  ),
  ProductData(
    image: AppImageStrings.product3,
    size: "",
    name: 'Earl Grey Tea',
    category: 'Tea',
    description: 'A classic Earl Grey tea with bergamot aroma.',
    rating: 4.1,
    price: 3.0,
    byRate: 19,
  ),
  ProductData(
    image: AppImageStrings.product4,
    size: "",
    name: 'Herbal Infusion',
    category: 'Tea',
    description: 'A soothing herbal tea blend for relaxation.',
    rating: 4.5,
    price: 3.5,
    byRate: 24,
  ),
  ProductData(
    image: AppImageStrings.product5,
    size: "",
    name: 'Peppermint Tea',
    category: 'Tea',
    description: 'A refreshing peppermint tea for a cool taste.',
    rating: 4.2,
    price: 3.8,
    byRate: 20,
  ),
  ProductData(
    image: AppImageStrings.product1,
    size: "",
    name: 'Berry Smoothie',
    category: 'Smoothie',
    description: 'A fruity berry smoothie with yogurt.',
    rating: 4.4,
    price: 5.0,
    byRate: 33,
  ),
  ProductData(
    image: AppImageStrings.product2,
    size: "",
    name: 'Mango Smoothie',
    category: 'Smoothie',
    description: 'A tropical mango smoothie with a creamy finish.',
    rating: 4.5,
    price: 5.2,
    byRate: 35,
  ),
  ProductData(
    image: AppImageStrings.product3,
    size: "",
    name: 'Banana Almond Shake',
    category: 'Smoothie',
    description: 'A protein-rich banana almond smoothie.',
    rating: 4.3,
    price: 5.5,
    byRate: 28,
  ),
  ProductData(
    image: AppImageStrings.product4,
    size: "",
    name: 'Strawberry Delight',
    category: 'Smoothie',
    description: 'A fresh strawberry smoothie with honey.',
    rating: 4.6,
    price: 5.3,
    byRate: 30,
  ),
  ProductData(
    image: AppImageStrings.product5,
    size: "",
    name: 'Avocado Power Shake',
    category: 'Smoothie',
    description: 'A healthy avocado smoothie for energy boost.',
    rating: 4.7,
    price: 5.8,
    byRate: 40,
  ),
];

}

// class ProductData {
//   // Dummy product data
//   final List<Map<String, dynamic>> products = [
//     {
//       'image': AppImageStrings.product1,
//       'title': 'Classic Latte',
//       'category': 'Hot Coffee',
//       'price': 150.0,
//       'rating': 4.2,
//       'description':
//           'A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.A creamy classic latte with a smooth finish.',
//       'size': 'm',
//       'byRate': 25
//     },
//     {
//       'image': AppImageStrings.product2,
//       'title': 'Vanilla Latte',
//       'category': 'Hot Coffee',
//       'price': 180.0,
//       'rating': 4.4,
//       'description': 'Sweet vanilla flavor blended into a rich latte.',
//       'size': 's',
//       'byRate': 30
//     },
//     {
//       'image': AppImageStrings.product3,
//       'title': 'Caramel Macchiato',
//       'category': 'Specialty Coffee',
//       'price': 200.0,
//       'rating': 4.7,
//       'description': 'Rich espresso with caramel and foamed milk.',
//       'size': 'l',
//       'byRate': 35
//     },
//     {
//       'image': AppImageStrings.product4,
//       'title': 'Espresso Shot',
//       'category': 'Espresso',
//       'price': 120.0,
//       'rating': 4.6,
//       'description': 'A single shot of bold espresso.',
//       'size': 's',
//       'byRate': 40
//     },
//     {
//       'image': AppImageStrings.product5,
//       'title': 'Cappuccino Supreme',
//       'category': 'Hot Coffee',
//       'price': 190.0,
//       'rating': 4.5,
//       'description': 'Perfectly steamed milk with rich espresso.',
//       'size': 'm',
//       'byRate': 28
//     },
//     {
//       'image': AppImageStrings.product1,
//       'title': 'Mocha Delight',
//       'category': 'Chocolate Coffee',
//       'price': 220.0,
//       'rating': 4.8,
//       'description': 'A perfect mix of espresso and chocolate.',
//       'size': 'l',
//       'byRate': 38
//     },
//     {
//       'image': AppImageStrings.product2,
//       'title': 'Cold Brew',
//       'category': 'Cold Coffee',
//       'price': 170.0,
//       'rating': 4.3,
//       'description': 'A refreshing cold brew coffee.',
//       'size': 'm',
//       'byRate': 33
//     },
//     {
//       'image': AppImageStrings.product3,
//       'title': 'Iced Americano',
//       'category': 'Cold Coffee',
//       'price': 160.0,
//       'rating': 4.1,
//       'description': 'Classic Americano served over ice.',
//       'size': 's',
//       'byRate': 27
//     },
//     {
//       'image': AppImageStrings.product4,
//       'title': 'Irish Coffee',
//       'category': 'Specialty Coffee',
//       'price': 250.0,
//       'rating': 4.9,
//       'description': 'Espresso blended with cream and a touch of whiskey.',
//       'size': 'l',
//       'byRate': 42
//     },
//     {
//       'image': AppImageStrings.product5,
//       'title': 'Turkish Coffee',
//       'category': 'Specialty Coffee',
//       'price': 200.0,
//       'rating': 4.6,
//       'description': 'Rich, aromatic Turkish coffee.',
//       'size': 'm',
//       'byRate': 30
//     },
//     {
//       'image': AppImageStrings.product1,
//       'title': 'Cinnamon Latte',
//       'category': 'Hot Coffee',
//       'price': 190.0,
//       'rating': 4.5,
//       'description': 'A warm latte with a hint of cinnamon.',
//       'size': 's',
//       'byRate': 26
//     },
//     {
//       'image': AppImageStrings.product2,
//       'title': 'Hazelnut Mocha',
//       'category': 'Chocolate Coffee',
//       'price': 230.0,
//       'rating': 4.7,
//       'description': 'Chocolate mocha with hazelnut flavor.',
//       'size': 'l',
//       'byRate': 34
//     },
//     {
//       'image': AppImageStrings.product3,
//       'title': 'Pumpkin Spice Latte',
//       'category': 'Specialty Coffee',
//       'price': 210.0,
//       'rating': 4.4,
//       'description': 'A seasonal favorite with pumpkin spice.',
//       'size': 'm',
//       'byRate': 37
//     },
//     {
//       'image': AppImageStrings.product4,
//       'title': 'Double Espresso',
//       'category': 'Espresso',
//       'price': 130.0,
//       'rating': 4.3,
//       'description': 'A bold double shot of espresso.',
//       'size': 's',
//       'byRate': 22
//     },
//     {
//       'image': AppImageStrings.product5,
//       'title': 'Flat White',
//       'category': 'Hot Coffee',
//       'price': 185.0,
//       'rating': 4.5,
//       'description': 'Smooth espresso with silky steamed milk.',
//       'size': 'm',
//       'byRate': 31
//     },
//     {
//       'image': AppImageStrings.product1,
//       'title': 'Matcha Latte',
//       'category': 'Flavored Coffee',
//       'price': 240.0,
//       'rating': 4.7,
//       'description': 'A latte with earthy matcha flavor.',
//       'size': 'l',
//       'byRate': 29
//     },
//     {
//       'image': AppImageStrings.product2,
//       'title': 'Nitro Cold Brew',
//       'category': 'Cold Coffee',
//       'price': 260.0,
//       'rating': 4.8,
//       'description': 'Creamy and bold nitro cold brew.',
//       'size': 'l',
//       'byRate': 40
//     },
//     {
//       'image': AppImageStrings.product3,
//       'title': 'Dark Roast',
//       'category': 'Hot Coffee',
//       'price': 140.0,
//       'rating': 4.2,
//       'description': 'Strong dark roast coffee.',
//       'size': 's',
//       'byRate': 18
//     },
//     {
//       'image': AppImageStrings.product4,
//       'title': 'White Chocolate Mocha',
//       'category': 'Chocolate Coffee',
//       'price': 225.0,
//       'rating': 4.6,
//       'description': 'A mocha with sweet white chocolate.',
//       'size': 'm',
//       'byRate': 35
//     },
//     {
//       'image': AppImageStrings.product5,
//       'title': 'Chai Latte',
//       'category': 'Flavored Coffee',
//       'price': 175.0,
//       'rating': 4.3,
//       'description': 'Spiced chai tea with steamed milk.',
//       'size': 'm',
//       'byRate': 24
//     },
//   ];
// }
