import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  // static final CameraPosition _kGooglePlex =
  //     CameraPosition(target: LatLng(37.427961, -122.085749), zoom: 12.0);

  // @override
  // void initState() {
  //   super.initState();
  //   // _requestLocationPermission();
  // }

  // Future<void> _requestLocationPermission() async {
  //   var status = await Permission.location.request();
  //   if (status.isGranted) {
  //     print("Location permission granted");
  //   } else {
  //     print("Location permission denied");
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(children: [],),
        // child: GoogleMap(
        //   initialCameraPosition: _kGooglePlex,
        //   // myLocationEnabled: true, // Shows user location
        //   // myLocationButtonEnabled: true,
        // ),
      ),
    );
  }
}
