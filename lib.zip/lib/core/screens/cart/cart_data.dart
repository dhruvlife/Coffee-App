
class CartData {
  final String image;
  final String name;
  final String category;
  final String description;
  final double rating;
  final double price;
  final String size;
  final int byRate;
  int quantity; // Added quantity to track the number of items of the same product in the cart

  CartData({
    required this.image,
    required this.name,
    required this.category,
    required this.description,
    required this.rating,
    required this.price,
    required this.size,
    required this.byRate,
    this.quantity = 1, // Default quantity is 1
  });
}
class CartManager {
  static List<CartData> cartData = [];
  
  static void addToCart(CartData cartDataItem) {
    // Check if the cart already contains the item based on some unique identifier
    bool itemExists = cartData.any((item) => item.name == cartDataItem.name);

    if (itemExists) {
      // If the item exists in the cart, update the quantity
      cartData.firstWhere((item) => item.name == cartDataItem.name).quantity++;
    } else {
      // If the item doesn't exist, add it to the cart
      cartData.add(cartDataItem);
    }
  }
   static double getTotalPrice() {
    return cartData.fold(0, (sum, item) => sum + (item.price * item.quantity));
  }
}




// class CartManager {
//   static List<CartData> cartData = [];

//   static void addToCart(CartData cartDataItem) {
//     // Check if the cart already contains the item based on some unique identifier
//     final existingItem = cartData.firstWhere(
//       (item) => item.name == cartDataItem.name,
//       orElse: () => null, // Return null if no match
//     );

//     if (existingItem != null) {
//       // If the item exists in the cart, update the quantity
//       existingItem.quantity++;
//     } else {
//       // If the item doesn't exist, add it to the cart
//       cartData.add(cartDataItem);
//     }
//   }
// }

  // static int addToCart(CartData cartItem) {
  //   try {
  //     // Check if the item already exists in the cart
  //     final existingItem = cartData.where(
  //       (item) => item.name == cartItem.name,
  //       // Provide a fallback value
  //     );

  //     if (existingItem == null) {
  //       // Add the item to the cart if it's not already there
  //       cartData.add(cartItem);
  //     } else {
  //       // Optionally, update the quantity or other properties of the existing item
  //       // For example:
  //      return cartItem.quantity += 1;
  //     }
  //   } catch (e) {
  //     print('Error adding item to cart: $e');
  //   }
  //   return cartItem.quantity += 1;
  // }

  // // Add item to cart
  // static void addToCart(CartData item) {
  //   final existingItem = cartData.firstWhere(
  //     (cartItem) => cartItem.name == item.name,
  //   );

  //   if (existingItem.name == item.name) {
  //     // If item already exists, increase quantity
  //     existingItem.quantity += item.quantity;
  //   } else {
  //     // If item doesn't exist, add it to the cart
  //     cartData.add(item);
  //   }
  // }

  // Remove item from cart
//   static void removeFromCart(String name) {
//     cartData.removeWhere((item) => item.name == name);
//   }

//   // Read a single item by its name
//   static CartData? readCartItemByName(String name) {
//     try {
//       return cartData.firstWhere((item) => item.name == name);
//     } catch (e) {
//       return null; // Return null if the item is not found
//     }
//   }

//   // Clear all items from the cart
//   static void clearCart() {
//     cartData.clear();
//   }

//   // Get total price of items in the cart
//   static double getTotalPrice() {
//     double total = 0.0;
//     for (var item in cartData) {
//       total += item.price * item.quantity;
//     }
//     return total;
//   }
// }
