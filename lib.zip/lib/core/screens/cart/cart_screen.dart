// import 'package:figmawc/core/data/product/product_data.dart';
// import 'package:figmawc/core/screens/cart/cart_data.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_appbar.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_design.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_divider.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_price_section.dart';
// import 'package:figmawc/utils/constants/app_colors.dart';
// import 'package:figmawc/utils/constants/app_sizes.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';

// class CartScreen extends StatefulWidget {
//   final CartData ? cartData;
//   const CartScreen({
//     super.key, this.cartData,
//   });

//   @override
//   State<CartScreen> createState() => _CartScreenState();
// }

// class _CartScreenState extends State<CartScreen> {
//   final cartItems = CartManager.readCartByName(widget.cartData.name.toString() ?? "" );
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       // appBar: AppBar(
//       //   title: ,centerTitle: true,
//       // ),
//       body: SafeArea(
//         child: Column(
//           children: [
//             CartAppBar().paddingSymmetric(vertical: 16.h),
//             // Cart(),

//             SizedBox(
//               height: 20.h,
//             ),

//             CartDivider().paddingOnly(bottom: 10.h),
//             CartPriceSection(),
//             Expanded(
//               child: ListView.builder(
//                 itemCount: 0,
//                 itemBuilder: (context, index) {
//                   return Cart(cartData: cartItems.,);
//                 },
//               ),
//             ),
//             CartDivider().paddingOnly(bottom: 10.h),
//             SizedBox(
//               height: 50.h,
//               width: double.infinity,
//               child: ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                     shape: RoundedRectangleBorder(
//                         borderRadius:
//                             BorderRadius.circular(AppSize.buttonRadius)),
//                     backgroundColor: AppColors.button),
//                 onPressed: () {},
//                 child: Text(
//                   "Place Order",
//                   style: TextStyle(color: AppColors.white),
//                 ),
//               ),
//             ),
//           ],
//         ).paddingSymmetric(horizontal: 24.w, vertical: 10.h),
//       ),
//     );
//   }
// }

// import 'package:figmawc/core/screens/cart/cart_data.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_appbar.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_design.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_divider.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_price_section.dart';
// import 'package:figmawc/utils/constants/app_colors.dart';

// import 'package:figmawc/utils/constants/app_sizes.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';

// class CartScreen extends StatefulWidget {

//   const CartScreen({
//     super.key,

//   });

//   @override
//   State<CartScreen> createState() => _CartScreenState();
// }

// class _CartScreenState extends State<CartScreen> {
//   CartData? cartItems;

//   @override
//   void initState() {
//     super.initState();
//     cartItems = CartManager.readCart;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: Column(
//           children: [
//             CartAppBar().paddingSymmetric(vertical: 16.h),
//             SizedBox(height: 20.h),
//             // Cart(cartData: CartData(image: AppImageStrings.banner, name: "", category: "", description: "", rating: 10, price: 10, size:"", byRate:10)),
//             Expanded(
//               child: cartItems != null
//                   ? ListView.builder(
//                       itemCount: CartManager
//                           .cartData.length, // Only one item is being displayed
//                       itemBuilder: (context, index) {
//                         return Cart(
//                           cartData: cartItems!,
//                         );
//                       },
//                     )
//                   : Center(
//                       child: Text(
//                         "No items in cart",
//                         style: TextStyle(fontSize: 18.sp),
//                       ),
//                     ),
//             ),
//             CartDivider().paddingOnly(bottom: 10.h),
//             CartPriceSection(),
//             CartDivider().paddingOnly(bottom: 10.h),
//             SizedBox(
//               height: 50.h,
//               width: double.infinity,
//               child: ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(AppSize.buttonRadius),
//                   ),
//                   backgroundColor: AppColors.button,
//                 ),
//                 onPressed: () {},
//                 child: Text(
//                   "Place Order",
//                   style: TextStyle(color: AppColors.white),
//                 ),
//               ),
//             ),
//           ],
//         ).paddingSymmetric(horizontal: 24.w, vertical: 10.h),
//       ),
//     );
//   }
// }

// import 'package:figmawc/core/screens/cart/cart_data.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_appbar.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_design.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_divider.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_price_section.dart';
// import 'package:figmawc/utils/constants/app_colors.dart';
// import 'package:figmawc/utils/constants/app_sizes.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';

// class CartScreen extends StatefulWidget {
//   const CartScreen({super.key});

//   @override
//   State<CartScreen> createState() => _CartScreenState();
// }

// class _CartScreenState extends State<CartScreen> {
//   List<CartData> cartItems = []; // Corrected: This should be a list

//   @override
//   void initState() {
//     super.initState();
//     cartItems = CartManager.readCart(); // Fetch cart data correctly
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: Column(
//           children: [
//             CartAppBar().paddingSymmetric(vertical: 16.h),
//             SizedBox(height: 20.h),
//             Expanded(
//               child: cartItems.isNotEmpty
//                   ? ListView.builder(
//                       itemCount: cartItems.length, // Corrected: Use cartItems list length
//                       itemBuilder: (context, index) {
//                         return Cart(
//                           cartData: cartItems[index], // Pass each item individually
//                         );
//                       },
//                     )
//                   : Center(
//                       child: Text(
//                         "No items in cart",
//                         style: TextStyle(fontSize: 18.sp),
//                       ),
//                     ),
//             ),
//             CartDivider().paddingOnly(bottom: 10.h),
//             CartPriceSection(),
//             CartDivider().paddingOnly(bottom: 10.h),
//             SizedBox(
//               height: 50.h,
//               width: double.infinity,
//               child: ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(AppSize.buttonRadius),
//                   ),
//                   backgroundColor: AppColors.button,
//                 ),
//                 onPressed: () {},
//                 child: Text(
//                   "Place Order",
//                   style: TextStyle(color: AppColors.white),
//                 ),
//               ),
//             ),
//           ],
//         ).paddingSymmetric(horizontal: 24.w, vertical: 10.h),
//       ),
//     );
//   }
// }
// import 'package:figmawc/core/screens/cart/cart_data.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_appbar.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_design.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_divider.dart';
// import 'package:figmawc/core/screens/cart/widget/cart_price_section.dart';
// import 'package:figmawc/utils/constants/app_colors.dart';
// import 'package:figmawc/utils/constants/app_sizes.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';

// class CartScreen extends StatefulWidget {
//   const CartScreen({super.key});

//   @override
//   State<CartScreen> createState() => _CartScreenState();
// }
// late List<CartData> cartData;

// class _CartScreenState extends State<CartScreen> {
//   @override
//   void initState() {

//     super.initState();
//     List<CartData> cartData = CartManager.cartData;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: Column(
//           children: [
//             CartAppBar().paddingSymmetric(vertical: 16.h),
//             SizedBox(height: 20.h),
//             Expanded(
//               child: cartData.isNotEmpty
//                   ? ListView.builder(
//                       itemCount: cartData.length,
//                       itemBuilder: (context, index) {
//                         return Cart(
//                           cartData: cartData[index],
//                         );
//                       },
//                     )
//                   : Center(
//                       child: Text(
//                         "No items in cart",
//                         style: TextStyle(fontSize: 18.sp),
//                       ),
//                     ),
//             ),
//             CartDivider().paddingOnly(bottom: 10.h),
//             CartPriceSection(),
//             CartDivider().paddingOnly(bottom: 10.h),
//             SizedBox(
//               height: 50.h,
//               width: double.infinity,
//               child: ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(AppSize.buttonRadius),
//                   ),
//                   backgroundColor: AppColors.button,
//                 ),
//                 onPressed: () {},
//                 child: Text(
//                   "Place Order",
//                   style: TextStyle(color: AppColors.white),
//                 ),
//               ),
//             ),
//           ],
//         ).paddingSymmetric(horizontal: 24.w, vertical: 10.h),
//       ),
//     );
//   }
// }

import 'package:figmawc/core/screens/cart/cart_data.dart';
import 'package:figmawc/core/screens/cart/widget/cart_appbar.dart';
import 'package:figmawc/core/screens/cart/widget/cart_design.dart';
import 'package:figmawc/core/screens/cart/widget/cart_divider.dart';
import 'package:figmawc/core/screens/cart/widget/cart_price_section.dart';
import 'package:figmawc/utils/constants/app_colors.dart';
import 'package:figmawc/utils/constants/app_sizes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  List<CartData> cartData = CartManager.cartData;
  
  late double totalPrice;
  // Declare the cartData here
  // late List<CartData> cartData;

  // @override
  // void initState() {
  //   super.initState();
  //   // Initialize cartData with CartManager's cartData
  //   cartData = CartManager.cartData;
  // }
  @override
  void initState() {
    totalPrice = CartManager.getTotalPrice();
    super.initState();
  }
  
  void removeItemFromCart(CartData cartItem) {
    setState(() {
      cartData.remove(cartItem);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Item Removed Successfully")),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            CartAppBar().paddingSymmetric(vertical: 16.h),
            SizedBox(height: 20.h),
            Expanded(
              child: cartData.isNotEmpty
                  ? ListView.builder(
                      itemCount:  cartData.length,
                      itemBuilder: (context, index) {
                        return Cart(
                          cartData:  CartManager.cartData[index], onRemove:  removeItemFromCart,
                        );
                      },
                    )
                  : Center(
                      child: Text(
                        "No items in cart",
                        style: TextStyle(fontSize: 18.sp),
                      ),
                    ),
            ),
            CartDivider().paddingOnly(bottom: 10.h),
            CartPriceSection(totalPrice: CartManager.getTotalPrice(),),
            CartDivider().paddingOnly(bottom: 10.h),
            SizedBox(
              height: 50.h,
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppSize.buttonRadius),
                  ),
                  backgroundColor: AppColors.button,
                ),
                onPressed: () {},
                child: Text(
                  "Place Order",
                  style: TextStyle(color: AppColors.white),
                ),
              ),
            ),
          ],
        ).paddingSymmetric(horizontal: 24.w, vertical: 10.h),
      ),
    );
  }
}
