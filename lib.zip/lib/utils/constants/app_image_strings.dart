class AppImageStrings {
  static const String onboarding = "assets/images/imageOnboarding.png";
  static const String banner = "assets/images/banner.png";
  static const String product1 = "assets/images/1.png";
  static const String product2 = "assets/images/2.png";
  static const String product3 = "assets/images/3.png";
  static const String product4 = "assets/images/4.png";
  static const String product5 = "assets/images/5.png";

}