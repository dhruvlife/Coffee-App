class AppTimes {
  static int splashSecond = 3;
}
