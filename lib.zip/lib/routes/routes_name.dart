class RoutesName {
  static const String splash = '/splash';
  static const String home = '/home';
  static const String bottomMenu = '/bottomMenu';
  static const String productView = '/productView';
  static const String order = '/order';
  static const String cart = '/cart';
}
